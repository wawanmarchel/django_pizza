from django.contrib import admin
from pizza.models import pizza, region, size, style, topping

admin.site.register(pizza.Pizza)
admin.site.register(region.Region)
admin.site.register(size.Size)
admin.site.register(style.Style)
admin.site.register(topping.Topping)

# Register your models here.
