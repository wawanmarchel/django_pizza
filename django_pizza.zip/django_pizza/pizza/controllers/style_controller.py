from django.shortcuts import render
# we import the models here, usually only one model
from pizza.models.style import Style

def index(request):
    styles = Style.objects.all()
    data = {
        'styles' : styles,
    }
    # render to our html
    return render(request, 'index.html', context=data)