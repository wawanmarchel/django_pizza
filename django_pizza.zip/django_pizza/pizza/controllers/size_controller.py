from django.shortcuts import render
from pizza.models.size import Size

def index(request):
    sizes = Size.object.all()
    data = {
        'sizes' : sizes,
    }
    return render(request,'index.html', context=data)