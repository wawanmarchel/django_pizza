from django.shortcuts import render
# we import the models here, usually only one model
from pizza.models.topping import Topping

def index(request):
    toppings = Topping.objects.all()
    data = {
        'toppings' : toppings,
    }
    # render to our html
    return render(request, 'index.html', context=data)