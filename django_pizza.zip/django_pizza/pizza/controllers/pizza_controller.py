from django.shortcuts import render
# we import the models here, usually only one model
from pizza.models.pizza import Pizza

def index(request):
    pizzas = Pizza.objects.all() # get all pizzas
    # put in data dictionary
    data = {
    'pizzas': pizzas,
    }
    # render to our html
    return render(request, 'index.html', context=data)