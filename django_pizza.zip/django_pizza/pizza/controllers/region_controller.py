from django.shortcuts import render
from pizza.models.region import Region

def index(request):
    regions = Region.object.all()
    data = {
        'regions' : regions,
    }
    return render(request, 'index.html', context=data)