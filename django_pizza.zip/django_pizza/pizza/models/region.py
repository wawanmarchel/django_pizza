from django.db import models

class Region(models.Model):
    """ pizza unique region """
    name = models.CharField(max_length = 100)

    class Meta:
        app_label = 'pizza'

    def str (self):
        return f'(self.name)'