from django.db import models

class Size(models.Model):
    """ pizza size data """
    name = models.CharField(max_length=100)
    diameter = models.FloatField()
    
    class Meta:
        app_label = 'pizza'
 
    def __str__(self):
        return f'{self.name} ({self.diameter})'