from django.db import models
from pizza.models.size import Size
from pizza.models.style import Style
from pizza.models.topping import Topping

class Pizza(models.Model):
    """ pizza data """
    name = models.CharField(max_length=100)
    style = models.ForeignKey(Style, null=True, on_delete=models.SET_NULL)
    toppings = models.ManyToManyField(Topping)
    sizes = models.ManyToManyField(Size)
    
    class Meta:
        app_label = 'pizza'
    
    def __str__(self):
        return f'{self.name}'