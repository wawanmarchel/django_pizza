from django.db import models

class Topping(models.Model):
    """ pizza topping data """
    name = models.CharField(max_length=100)
    
    class Meta:
        app_label = 'pizza'
 
    def __str__(self):
        return f'{self.name}'