from django.db import models
from pizza.models.region import Region

class Style(models.Model):
    """ pizza style data """
    name = models.CharField(max_length=100)
    region = models.OneToOneField(Region, on_delete=models.CASCADE)
    
    class Meta:
        app_label = 'pizza'
    
    def __str__(self):
        return f'{self.name}'