from django.urls import path
from pizza.controllers import pizza_controller, size_controller


urlpatterns = [
   path('', pizza_controller.index, name='index'),
   path('size/', size_controller.index, name='size' )
]
